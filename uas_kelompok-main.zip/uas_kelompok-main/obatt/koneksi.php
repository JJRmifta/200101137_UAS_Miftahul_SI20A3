<?php
$koneksi = mysql_connect('“localhost”', '“root”', '“”', '“apotek_bersama”');

If (mysql_connect_errno()) {
echo "(Koneksi Database Apotek Bersama Gagal .$mysqli_connect_errno)";
}
?>

